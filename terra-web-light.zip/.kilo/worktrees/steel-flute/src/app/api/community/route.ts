import { withApiErrors } from "@/server/http/api-handler";
import { NextResponse } from "next/server";
import { communityRepository } from "@/server/observations/community.repository";
import { getSessionUserId } from "@/lib/session";
import { ORGANISM_GROUPS } from "@/types/nature";
import { publicCoordinates } from "@/server/observations/location";
import { isImageDataUrl, isStorageConfigured, storePublicImage } from "@/server/media/object-storage";

const MAX_IMAGE_DATA_URL_LENGTH = 1_250_000;
const MAX_REQUEST_LENGTH = 1_450_000;
const LOCATION_VISIBILITIES = ["PUBLIC", "APPROXIMATE", "PRIVATE"] as const;

function safeImageUrl(value: unknown): string | null {
  if (typeof value !== "string" || value.length > MAX_IMAGE_DATA_URL_LENGTH) return null;
  if (/^data:image\/(?:jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/.test(value)) return value;
  try {
    const url = new URL(value);
    return url.protocol === "https:" ? url.toString() : null;
  } catch {
    return value === "" ? "" : null;
  }
}
function safeVideoUrl(value: unknown): string | null {
  if (typeof value !== "string" || value.length > 2048) return null;
  if (/^\/api\/media\/observations\/[0-9a-f-]{36}\.(?:mp4|webm|mov)$/i.test(value)) return value;
  try { const url = new URL(value); return url.protocol === "https:" ? url.toString() : null; }
  catch { return value === "" ? "" : null; }
}
async function GETImpl(request: Request) {
  try {
    const viewerId = await getSessionUserId();
    if (!viewerId) return NextResponse.json({ error: "Connectez-vous pour voir les publications." }, { status: 401 });
    const { searchParams } = new URL(request.url);
    const region = searchParams.get("region");
    const group = searchParams.get("group");
    const q = searchParams.get("q")?.trim().slice(0, 80);
    const limit = Math.min(Math.max(Number(searchParams.get("limit") || 20), 1), 50);
    const validGroup = group && ORGANISM_GROUPS.includes(group as (typeof ORGANISM_GROUPS)[number])
      ? (group as (typeof ORGANISM_GROUPS)[number])
      : undefined;
    const posts = await communityRepository.listPosts({ removed: false, isEphemeral: false, ...(region ? { region } : {}), ...(validGroup ? { organismGroup: validGroup } : {}), ...(q ? { OR: [{ plantName: { contains: q } }, { scientificName: { contains: q } }, { region: { contains: q } }, { description: { contains: q } }] } : {}) }, viewerId, limit);
    return NextResponse.json({
      count: posts.length,
      data: posts.map((post) => {
        const { imageUrl, thumbnailUrl, ...observation } = post;
        const { postLikes, user, ...publicPost } = observation;
        const { followers, ...publicUser } = user;
        return { ...publicPost, user: { ...publicUser, following: followers.length > 0 }, following: followers.length > 0, liked: postLikes.length > 0, imageUrl: thumbnailUrl || imageUrl, ...publicCoordinates(post, viewerId) };
      }),
    });
  } catch (error) {
    console.error("Erreur observations:", error);
    return NextResponse.json({ error: "Erreur serveur" }, { status: 500 });
  }
}



export const GET = withApiErrors(GETImpl);

async function POSTImpl(request: Request) {
  try {
    const authorId = await getSessionUserId();
    if (!authorId) {
      return NextResponse.json({ error: "Connectez-vous pour publier une observation." }, { status: 401 });
    }
    const rawBody = await request.text();
    if (rawBody.length > MAX_REQUEST_LENGTH) {
      return NextResponse.json({ error: "La photo est trop lourde. Choisissez une image de moins de 850 Ko." }, { status: 413 });
    }
    const body = JSON.parse(rawBody) as Record<string, unknown>;
    const plantName = typeof body.plantName === "string" ? body.plantName.trim() : "";
    const description = typeof body.description === "string" ? body.description.trim() : "";
    if (plantName.length > 120 || description.length > 2000) {
      return NextResponse.json({ error: "Le nom ou la description est trop long." }, { status: 400 });
    }
    const imageUrl = safeImageUrl(body.imageUrl);
    const thumbnailUrl = safeImageUrl(body.thumbnailUrl);
    const videoUrl = safeVideoUrl(body.videoUrl);
    if (!imageUrl || !thumbnailUrl) {
      return NextResponse.json({ error: "Une photo et sa miniature sont nécessaires à cette observation." }, { status: 400 });
    }
    const requestedGroup = body.organismGroup;
    const organismGroup = typeof requestedGroup === "string" && ORGANISM_GROUPS.includes(requestedGroup as (typeof ORGANISM_GROUPS)[number])
      ? (requestedGroup as (typeof ORGANISM_GROUPS)[number])
      : "OTHER";
    const scientificName = typeof body.scientificName === "string" ? body.scientificName.trim().slice(0, 180) : "";
    const region = typeof body.region === "string" ? body.region.trim().slice(0, 120) || "Monde" : "Monde";
    const observedAt = new Date();
    const latitude = typeof body.latitude === "number" && Math.abs(body.latitude) <= 90 ? body.latitude : null;
    const longitude = typeof body.longitude === "number" && Math.abs(body.longitude) <= 180 ? body.longitude : null;
    const requestedVisibility = body.locationVisibility;
    const locationVisibility = typeof requestedVisibility === "string" && LOCATION_VISIBILITIES.includes(requestedVisibility as (typeof LOCATION_VISIBILITIES)[number])
      ? (requestedVisibility as (typeof LOCATION_VISIBILITIES)[number])
      : "APPROXIMATE";
    const publicShareEnabled = body.publicShareEnabled === true;
    const requestedProbability = body.identificationProbability;
    const identificationProbability = typeof requestedProbability === "number" && Number.isFinite(requestedProbability) && requestedProbability >= 0 && requestedProbability <= 1
      ? requestedProbability
      : null;
    if (publicShareEnabled && identificationProbability === null) {
      return NextResponse.json({ error: "Un score d’identification valide est requis pour créer une fiche partageable." }, { status: 400 });
    }
    const requestedSubmissionId = typeof body.clientSubmissionId === "string" ? body.clientSubmissionId : null;
    const clientSubmissionId = requestedSubmissionId && /^[a-zA-Z0-9_-]{8,80}$/.test(requestedSubmissionId) ? requestedSubmissionId : null;
    if (clientSubmissionId) {
      const existing = await communityRepository.findSubmission(clientSubmissionId);
      if (existing?.userId === authorId) return NextResponse.json({ observation: { ...existing, ...publicCoordinates(existing, authorId) }, duplicate: true });
      if (existing) return NextResponse.json({ error: "Identifiant de publication déjà utilisé." }, { status: 409 });
    }

    let storedImageUrl = imageUrl;
    let storedThumbnailUrl = thumbnailUrl;
    if (isImageDataUrl(imageUrl) || isImageDataUrl(thumbnailUrl)) {
      if (!isStorageConfigured()) return NextResponse.json({ error: "Le stockage photo n’est pas encore configuré." }, { status: 503 });
      try {
        [storedImageUrl, storedThumbnailUrl] = await Promise.all([
          storePublicImage(imageUrl, "observations"),
          storePublicImage(thumbnailUrl, "observations"),
        ]);
      } catch (error) {
        return NextResponse.json({ error: error instanceof Error ? error.message : "Envoi photo impossible." }, { status: 400 });
      }
    }
    const isEphemeral = body.isEphemeral === true;
    const post = await communityRepository.createPost({ userId: authorId, plantName: plantName || "Espèce non identifiée", scientificName, imageUrl: storedImageUrl, thumbnailUrl: storedThumbnailUrl, videoUrl: videoUrl || null, isEphemeral, expiresAt: isEphemeral ? new Date(Date.now() + 24 * 60 * 60 * 1000) : null, region, description: description || null, organismGroup, observedAt, latitude, longitude, locationVisibility, publicShareEnabled, identificationProbability, clientSubmissionId });
    return NextResponse.json({ observation: { ...post, ...publicCoordinates(post, authorId) } }, { status: 201 });
  } catch (error) {
    console.error("Erreur création observation:", error);
    return NextResponse.json({ error: "Erreur serveur" }, { status: 500 });
  }
}


export const POST = withApiErrors(POSTImpl);
