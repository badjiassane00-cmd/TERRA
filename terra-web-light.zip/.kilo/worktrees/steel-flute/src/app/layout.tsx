import type { Metadata } from "next";
import { Geist, Geist_Mono, Fraunces } from "next/font/google";
import "./globals.css";
import NatureAppHeader from "@/components/navigation/NatureAppHeader";
import { getSessionUser } from "@/lib/session";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

const fraunces = Fraunces({
  variable: "--font-fraunces",
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
});

export const metadata: Metadata = {
  title: "TERRA — Le réseau mondial du vivant",
  description: "Le réseau mondial du vivant : observez, identifiez et partagez les plantes, insectes, oiseaux et animaux autour de vous.",
  manifest: "/manifest.json",
  appleWebApp: {
    capable: true,
    title: "TERRA",
    statusBarStyle: "black-translucent",
  },
  icons: {
    icon: [{ url: "/icon-192.png", sizes: "192x192", type: "image/png" }],
    apple: [{ url: "/apple-touch-icon.png", sizes: "180x180", type: "image/png" }],
  },
};

export const viewport = {
  themeColor: "#71b879",
};

export default async function RootLayout({ children }: LayoutProps<"/">) {
  const user = await getSessionUser();
  return (
    <html
      lang="fr"
      className={`${geistSans.variable} ${geistMono.variable} ${fraunces.variable} h-full antialiased`}
    >
      <body className="min-h-full flex flex-col bg-background">
        <NatureAppHeader user={user ? { id: user.id, name: user.name, avatarUrl: user.avatarUrl, role: user.role } : null} />
        {children}
      </body>
    </html>
  );
}
